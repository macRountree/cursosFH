export function someMutation (/* state */) {
    
}

export function toggleSideMenu( state ) {
    state.isSideMenuOpen = !state.isSideMenuOpen
}
