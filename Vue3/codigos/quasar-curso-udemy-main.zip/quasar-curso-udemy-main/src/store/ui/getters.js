export function someGetter (/* state */) {
}

export function isSideMenuOpen (state) {
    return state.isSideMenuOpen
}
