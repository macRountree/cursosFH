export default function () {
  return {
    isSideMenuOpen: true
  }
}
