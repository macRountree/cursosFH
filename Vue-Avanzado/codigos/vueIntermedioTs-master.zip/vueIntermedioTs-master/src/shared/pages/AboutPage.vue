<template>
    <div>
        <h1>AbaoutPage</h1>
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>